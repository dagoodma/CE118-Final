/*
 * File:   main.c
 * Author: dagoodma
 *
 * Created on February 21, 2012, 7:46 PM
 */

#define USE_MAIN

#ifdef USE_MAIN
#include <p32xxxx.h>
#include "serial.h"
#include "PORTS.h"
#include "timers.h"
#include "Drive.h"
#include "Gate.h"
#include "TapeSensor.h"
//#include "IR.h"
#include "Bumper.h"
#include "AD.h"


/*******************************************************************************
 * #DEFINES                                                                    *
 ******************************************************************************/
#define TIMER_START 5
#define TIMER_MOVE 6
#define START_DELAY 4500 // ms
#define DUMP_DELAY 2500
#define REVERSE_DELAY 5000
#define TURN_DELAY 1500
#define FORWARD_DELAY 2500

#define IR_MAX_DIFFERENCE 10 // threshold for find_max
#define IR_MIN_DIFFERENCE 3 // threshold for return_max

#define DEBUG_VERBOSE
#ifdef DEBUG_VERBOSE
    #define dbprintf(...) printf(__VA_ARGS__)
#else
    #define dbprintf(...)
#endif

/*******************************************************************************
 * VARIABLES                                                                   *
 ******************************************************************************/

//---------- Top state variables ------------
static enum { target, charge, find_tape, follow_tape, hold} topState;
//static enum { none, acquired_target, lost_target, dumped, arm_on, found_island} topEvent = none;

//-------- Target state variables -----------
static unsigned int highestIRSeen = 0;
static enum { target_findmax, target_returnmax } targetState = target_findmax;
static enum { target_none, target_highestpast, target_foundmax } targetEvent = target_none;

//-------- Charge state variables -----------
static enum { charge_forward, charge_dump, charge_reverse, charge_turn,
        charge_avoidtape} chargeState = target;
static enum { charge_none, charge_lostbeacon, charge_hit, charge_hittape,
        charge_blocked, charge_dumped, charge_avoided, charge_escaped } chargeEvent = charge_none;

//-------- AvoidTape state variables -----------
static enum { avoid_transition, avoid_reverse, avoid_turnleft, avoid_turnright,
        avoid_forward, avoid_revturnleft} avoidState = avoid_transition;
static enum { avoid_none, avoid_goback, avoid_cutright, avoid_goright,
    avoid_goleft, avoid_cutleft, avoid_reversed, avoid_lefted, avoid_righted,
    avoid_forwarded, avoid_failed, avoid_revover} avoidEvent = avoid_none;

/*******************************************************************************
 * FUNCTION  PROTOTYPES                                                        *
 ******************************************************************************/
void HandleTopSM();

void DuringChargeSM();
void DuringTargetSM();
void DuringAvoidTapeSM();

void UpdateChargeEvent();
void UpdateAvoidTapeEvent();
void UpdateTargetEvent();

void InitChargeSM();
void InitTargetSM();
void InitAvoidTapeSM();

// -------- others -------
void wait();

/*
 * @Function DuringTargetSM
 * @remark
 * @date 2012.3.6 08:30 */
void DuringTargetSM() {
    UpdateTargetEvent();
    dbprintf("\nHandling TargetSM");
/*
    switch (targetState) {
        case target_findmax:
            if (targetEvent == target_highestpast)
                targetState = target_returnmax;
            else
                Drive_Turn(pivot,right,FULL_SPEED);
            break;
        case target_returnmax:
            if (targetEvent == target_foundmax) {
                Drive_Stop();
                // EXIT -- caller picks this up
            }
            else {
                Drive_Turn(pivot, left, FULL_SPEED);
            }
            break;
        default:
            printf("\nHorrible error occured!");

    } // switch
 * */
} // DuringTargetSM()


/*
 * @Function UpdateTargetEvent
 * @remark
 * @date 2012.3.6 08:30 */
void UpdateTargetEvent() {
    unsigned int reading = IR_MainReading();
    targetEvent = target_none;
     // TODO use timer for returnmax
    /*
    switch (targetState) {
        case target_findmax:
            if (reading > highestIRSeen && IR_MainTriggered()) {
                highestIRSeen = reading;
            }
            else if (reading < (highestIRSeen - IR_MAX_DIFFERENCE)) {
                // found max and dropping
                targetEvent = target_highestpast;
            }
            break;
        case target_returnmax:
            if (reading >= (highestIRSeen - IR_MIN_DIFFERENCE))
                targetEvent = target_foundmax;
            break;
    } // switch(
*/
            
} // UpateTargetEvent()

/*
 * @Function DuringChargeSM
 * @remark
 * @date 2012.3.6 08:30 */
void DuringChargeSM() {
    UpdateChargeEvent();
    dbprintf("\nHandling ChargeSM %i", chargeEvent);

    switch (chargeState) {
        case charge_forward:
            if (chargeEvent == charge_lostbeacon) {
                // EXIT - caller picks this up
            }
            else if(chargeEvent == charge_hit) {
                chargeState = charge_dump;
                Drive_Stop();
                Gate_Open();
                InitTimer(TIMER_MOVE, DUMP_DELAY);
            }
            else if(chargeEvent == charge_hittape) {
                InitAvoidTapeSM();
                chargeState = charge_avoidtape;
            }
            else {
                Drive_Forward(HALF_SPEED);
            }
            break;
        case charge_avoidtape:
            DuringAvoidTapeSM();
            if (chargeEvent == charge_avoided)
                chargeState = charge_forward;
            break;
        case charge_dump:
            if (chargeEvent == charge_blocked) {
                chargeState = charge_reverse;
                InitTimer(TIMER_MOVE, REVERSE_DELAY);
            }
            else if (chargeEvent == charge_dumped) {
                // EXIT - caller picks this up
            }
            break;
        case charge_reverse:
            if (chargeEvent == charge_escaped) {
                chargeState = charge_turn;
                InitTimer(TIMER_MOVE, TURN_DELAY);
            }
            else {
                Drive_Reverse(HALF_SPEED);
            }
            break;
        case charge_turn:
            if (chargeEvent == charge_dumped) {
                // EXIT - caller picks this up
            }
            else {
                Drive_Stop();
            }
            break;

        default:
           printf("\nA horrible error occured!");
    } // switch
}

/*
 * @Function UpdateChargeEvent
 * @remark
 * @date 2012.3.6 08:30 */
void UpdateChargeEvent() {
    chargeEvent = charge_none;

    switch (chargeState) {
        case charge_forward:
            // TODO improve define names
            if (!IR_MainTriggered()) {
            // if (!1) {
                chargeEvent = charge_lostbeacon;
            }
            else if((Tape_AnyTriggered() && IsTimerExpired(TIMER_START) ) {
                && ! (IR_MainTriggered() && IR_AngleTriggered()) ) {
                // hit tape, start timer expired,
                // and enemy is not right in front
                chargeEvent = charge_hittape;
            }
            else if(Bumper_AnyTriggered()) {
                chargeEvent = charge_hit;
            }
            break;
        case charge_avoidtape:
            if ( avoidEvent = avoid_forwarded )
                chargeEvent = charge_avoided;
            break;
        case charge_dump:
            if (IsTimerExpired(TIMER_MOVE)) {
                //if (IR_MainTriggered() && IR_AngleTriggered)
                if (1 && 0)
                    chargeEvent = charge_blocked;
                else
                    chargeEvent = charge_dumped;
            }
            break;
        case charge_reverse:
            if (IsTimerExpired(TIMER_MOVE) || Tape_BackTriggered())
                chargeEvent = charge_escaped;

        case charge_turn:
            if (IsTimerExpired(TIMER_MOVE) || Tape_BackTriggered())
                chargeEvent = charge_dumped;
            break;


    } // switch
}
/*
 * @Function DuringAvoidTapeSM
 * @remark
 * @date  */
void DuringAvoidTapeSM() {
    UpdateAvoidTapeEvent();
    dbprintf("\nHandling AvoidSM %i", avoidEvent);
    switch(avoidState){
        case avoid_transition:
            ClearTimerExpired(TIMER_MOVE);
            if (avoidEvent == avoid_goback) {
                Drive_Reverse(HALF_SPEED);
                InitTimer(TIMER_MOVE, REVERSE_DELAY);
                avoidState = avoid_reverse;
            }
            else if (avoidEvent == avoid_cutleft) {
               Drive_Turn(hard, left, HALF_SPEED);
               avoidState = avoid_turnleft;
            }
            else if (avoidEvent == avoid_goleft) {
                Drive_Turn(soft, left, HALF_SPEED);
                avoidState = avoid_turnleft;
            }
            else if (avoidEvent == avoid_cutright) {
                Drive_Turn(hard, right, HALF_SPEED);
                avoidState = avoid_turnright;
            }
            else if (avoidEvent == avoid_goright) {
                Drive_Turn(soft, right, HALF_SPEED);
                avoidState = avoid_turnright;
            }
            else {
                // avoidEvent == avoid_forwarded
                Drive_Stop();
                // EXIT - caller picks this up
            }
            break;
        case avoid_reverse:
            if(avoidEvent == avoid_reversed) {
                Drive_Turn(hard, left, HALF_SPEED);
                InitTimer(TIMER_MOVE, TURN_DELAY);
                avoidState = avoid_revturnleft;
            }
            break;
        case avoid_revturnleft:
            if(avoidEvent == avoid_revover) {
                InitTimer(TIMER_MOVE, TURN_DELAY);
                avoidState = avoid_forward;
            }
        case avoid_turnleft:
            if(avoidEvent == avoid_lefted) {
                InitTimer(TIMER_MOVE, FORWARD_DELAY);
                avoidState = avoid_forward;
            }
            break;
        case avoid_turnright:
            if(avoidEvent == avoid_righted) {
                InitTimer(TIMER_MOVE, FORWARD_DELAY);
                avoidState = avoid_forward;
            }
            break;
        case avoid_forward:
            if (avoidEvent == avoid_forwarded) {
                Drive_Stop();
                // EXIT - caller picks this up
            }
            else if (avoidEvent == avoid_failed) {
                Drive_Stop();
                avoidState = avoid_transition;
            }
            else {
                Drive_Forward(HALF_SPEED);
            }
            break;

    }//switch
}

/*
 * @Function UpdateAvoidTapeEvent
 * @remark
 * @date 2012.3.6 08:30 */
void UpdateAvoidTapeEvent() {
    avoidEvent = avoid_none;

    switch(avoidEvent){
        case avoid_transition:
            if ((Tape_LeftTriggered() && Tape_CenterTriggered() && Tape_AnyRightTriggered())) {
                // 111
                avoidEvent = avoid_goback;
            }
            else if (!Tape_LeftTriggered() && Tape_CenterTriggered() && Tape_AnyRightTriggered()) {
                // 011
                avoidEvent = avoid_cutleft;
            }
            else if (!Tape_LeftTriggered() && !Tape_CenterTriggered() && Tape_AnyRightTriggered()) {
                // 001
                avoidEvent = avoid_goleft;
            }
            else if (Tape_LeftTriggered() && !Tape_CenterTriggered() && !Tape_AnyRightTriggered()) {
                // 100
                avoidEvent = avoid_goright;
            }
            else if (Tape_LeftTriggered() && Tape_CenterTriggered() && !Tape_AnyRightTriggered()) {
                // 110
                avoidEvent = avoid_cutright;
            }
            //added
            else if (Tape_LeftTriggered() && !Tape_CenterTriggered() && Tape_AnyRightTriggered()) {
                // 101
                avoidEvent = avoid_goback;
            }
            else if (!Tape_LeftTriggered() && Tape_CenterTriggered() && !Tape_AnyRightTriggered()) {
                //010
                avoidEvent = avoid_goback;
            }
            //
            else {
                // Not sure, just exit state machine
                avoidEvent = avoid_forwarded;
            }
            break;
        case avoid_reverse:
            if (IsTimerExpired(TIMER_MOVE)) {
                avoidEvent = avoid_reversed;
            }
            break;
        case avoid_turnleft:
            if (IsTimerExpired(TIMER_MOVE) || !Tape_RightTriggered()) {
                avoidEvent = avoid_lefted;
            }
        case avoid_revturnleft:
            if (IsTimerExpired(TIMER_MOVE)) {
                avoidEvent = avoid_revover;
            }
            break;
        case avoid_turnright:
            if (!Tape_LeftTriggered())
                avoidEvent = avoid_righted;
            break;
        case avoid_forward:
            if (Tape_AnyTriggered()) {
                avoidEvent = avoid_failed;
            }
            else if(IsTimerExpired(TIMER_MOVE)) {
                avoidEvent = avoid_forwarded;
            }
            break;
    }//switch

}

// ----------------------- Main state machine handler -----------------
/*
 * @Function HandleTopSM
 * @remark
 * @date 2012.3.6 08:30 */
void HandleTopSM() {
    
    // Sub state machines handle topEvents
    switch (topState) {
        case target:
            //DuringTargetSM();
            if (targetEvent == target_foundmax || 1) {
                topState = charge;
                InitChargeSM();
            }
            break;

        case charge:
            DuringChargeSM();
            if (chargeEvent == charge_dumped)  {
                // TODO code rest of state machine
                //topState = find_tape; 
                topState = hold;
               printf("\nDone. Code rest of state machine.");
            }
            else if (chargeEvent == charge_lostbeacon) {
                topState = target;
                InitTargetSM();
            }
            break;
        case find_tape:
            // TODO code rest of state machine
            break;
        case follow_tape:
            // TODO code rest of state machine
            break;
        default:
          printf("\nHorrible error occured!");
    } // switch
 }

/*******************************************************************************
 * ENTRY POINT                                                                 *
 ******************************************************************************/

int main(void) {

    // ---------------------------- Initialization ----------------------------
    SERIAL_Init();
    TIMERS_Init();

    // Initialize modules
    Tape_Init();
    Drive_Init();
    Bumper_Init();
    Gate_Init();
    //IR_Init();

    // Initialize AD system
    unsigned int IR_PIN = 0;
#ifdef IR_ADC
    IR_PIN = IR_READ;
#endif
    AD_Init(TAPE_LEFT | TAPE_CENTER | TAPE_RIGHT | TAPE_BACK |
        TAPE_ARMFRONT | TAPE_ARMLEFT | TAPE_ARMRIGHT | IR_PIN );

    // Initialize state machine
    topState = charge;
    InitTimer(TIMER_START, START_DELAY);

    // Initialize interrupts
    INTEnableSystemMultiVectoredInt();

    printf("\nHello, I am working...");

    // ------------------------------- Main Loop -------------------------------
    while (1) {
        // Handle updates and module state machines
        Tape_HandleSM();
        // IR_HandleSM();
        Drive_Update();
        Bumper_Update();

        HandleTopSM();


        if (topState == hold)
            break;

        printf("\nTopSTATE! %i", topState);

        while (!IsTransmitEmpty()); // bad, this is blocking code
    }

    Tape_End();
    //Drive_End();
    Bumper_End();
    Gate_End();
    IR_End();

    return 0;
} // end of main()


void InitChargeSM() {
    chargeState = charge_forward;
}

void InitTargetSM() {
    targetState = target_findmax;
    highestIRSeen = 0;
}

void InitAvoidTapeSM() {
    avoidState = avoid_transition;
}

/**
* Function: wait
* @return Nothing
* @remark Waits a small period of time
*/
void wait() {
    unsigned int wait = 0;
    for (wait = 0; wait <= 1000000; wait++)
        asm("nop");
}

// ---------------------- EOF ----------------------
#endif
